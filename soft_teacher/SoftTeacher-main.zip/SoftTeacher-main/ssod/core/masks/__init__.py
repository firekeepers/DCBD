from .structures import TrimapMasks
